"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Loader2 } from "lucide-react";
// Import the styles
import "./styles.css";

type HistoryItem = {
  id: string;
  verdict: "likely_fake" | "uncertain" | "likely_legit";
  score: number;
  created_at: string;
  title?: string;
};

export default function HistoryPage() {
  const [items, setItems] = useState<HistoryItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const res = await fetch("/api/history");
        const data = (await res.json()) as HistoryItem[];
        setItems(data);
      } catch {
        setItems([]);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  return (
    <section className="history-container">
      <div className="header-section">
        <div className="history-title">History</div>
        <div className="history-subtitle">Previously analyzed job posts.</div>
      </div>

      {loading ? (
        <div className="loading-indicator">
          <Loader2 className="loader-icon" /> Loading…
        </div>
      ) : items.length ? (
        <div className="history-list">
          {items.map((it) => (
            <Link
              key={it.id}
              href={`/report/${encodeURIComponent(it.id)}`}
              className="history-item"
            >
              <div className="history-item-header">
                <div className="history-item-title">{it.title ?? `Report ${it.id}`}</div>
                <div className="history-item-date">
                  {new Date(it.created_at).toLocaleString()}
                </div>
              </div>
              <div className="history-item-details">
                Verdict: <span className="history-item-verdict">{it.verdict}</span> • Score:{" "}
                <span className="history-item-score">{it.score}/100</span>
              </div>
            </Link>
          ))}
        </div>
      ) : (
        <div className="no-history">No history yet.</div>
      )}
    </section>
  );
}
