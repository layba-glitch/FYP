import "../app/globals.css";  // Global CSS (reset, basic styling)
import ClientComponent from "./ClientComponent";
import './layout.css';         // Layout-specific CSS

import { Metadata } from "next"; // Metadata export (server-side)
import Link from "next/link";

// Layout-level metadata (this should remain in a server component)
export const metadata: Metadata = {
  title: "Fake Job Detector",
  description: "NLP-based fake job detection system",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <div className="container">
          <header className="header">
            <div className="logo-container">
              <div className="logo">FJ</div>
              <div className="title-container">
                <div className="title">Fake Job Detector</div>
                <div className="subtitle">Analyze job posts with NLP signals</div>
              </div>
            </div>

            <nav className="navbar">
              <Nav href="/">Analyze</Nav>
              <Nav href="/history">History</Nav>
              <Nav href="/about">About</Nav>
            </nav>
          </header>

          <section className="hero">
            <div className="hero-text">
              <h1>Welcome to Fake Job Detector</h1>
              <p>Use AI and NLP to analyze job posts and detect fraudulent listings.</p>
            </div>
          </section>

          <main className="main-content">{children}</main>

          <footer className="footer">
            <ClientComponent /> {/* This will handle client-specific logic */}
          </footer>
        </div>
      </body>
    </html>
  );
}

function Nav({ href, children }: { href: string; children: React.ReactNode }) {
  return (
    <Link href={href} className="nav-link">
      {children}
    </Link>
  );
}
