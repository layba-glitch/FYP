"use client";
import { useMemo, useState } from "react";
import { AlertTriangle, CheckCircle2, Link2, Loader2, Search, ShieldAlert } from "lucide-react";
import clsx from "clsx";
import styles from './page.module.css'; // Import the CSS Module

// Simple Card component definition
function Card({ children }: { children: React.ReactNode }) {
  return <div className={styles.card}>{children}</div>;
}

function VerdictBanner({ verdict, summary, confidence }: { verdict: string; summary: string; confidence: number }) {
  return (
    <div className={styles.verdictBanner}>
      <div className={styles.verdictIcon}>
        {verdict === "likely_legit" && <CheckCircle2 className="icon" />}
        {verdict === "likely_fake" && <AlertTriangle className="icon" />}
        {verdict === "uncertain" && <ShieldAlert className="icon" />}
      </div>
      <div className={styles.verdictContent}>
        <div className={styles.verdictTitle}>{verdict.replace(/_/g, " ")}</div>
        <div className={styles.verdictSummary}>{summary}</div>
        <div className={styles.confidenceScore}>Confidence: {(confidence * 100).toFixed(0)}%</div>
      </div>
    </div>
  );
}

type AnalyzeResponse = {
  id: string;
  verdict: "likely_fake" | "uncertain" | "likely_legit";
  score: number;
  confidence: number;
  summary: string;
  risk_factors: { label: string; severity: "low" | "medium" | "high"; detail: string }[];
  evidence: { text: string; kind: "pattern" | "metadata" | "language" | "link" }[];
  model: { name: string; version?: string };
  created_at: string;
};

async function safeText(res: Response): Promise<string> {
  try {
    return await res.text();
  } catch {
    return "";
  }
}

type CardHeaderProps = {
  title: string;
  subtitle?: string;
};

function CardHeader({ title, subtitle }: CardHeaderProps) {
  return (
    <div className={styles.cardHeader}>
      <div className={styles.cardHeaderTitle}>{title}</div>
      {subtitle && <div className={styles.cardHeaderSubtitle}>{subtitle}</div>}
    </div>
  );
}

function EmptyState() {
  return (
    <div className={styles.emptyState}>
      <div className={styles.emptyStateTitle}>No analysis yet</div>
      <div className={styles.emptyStateText}>
        Results will appear here after you analyze a job post.
      </div>
    </div>
  );
}

export default function AnalyzePage() {
  const [jobText, setJobText] = useState("");
  const [jobUrl, setJobUrl] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<AnalyzeResponse | null>(null);
  const [error, setError] = useState<string | null>(null);

  const canAnalyze = useMemo(() => jobText.trim().length > 30 || jobUrl.trim().length > 8, [jobText, jobUrl]);

  async function onAnalyze() {
    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const res = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: jobText.trim() || null, url: jobUrl.trim() || null }),
      });

      if (!res.ok) {
        const msg = await safeText(res);
        throw new Error(msg || "Analyze request failed.");
      }

      const data = (await res.json()) as AnalyzeResponse;
      setResult(data);
    } catch (e: any) {
      setError(e?.message ?? "Something went wrong.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className={styles.analyzeContainer}>
      <div className={styles.leftSection}>
        <Card>
          <CardHeader title="Analyze a job post" subtitle="Paste the job description or provide a URL." />
          <div className={styles.inputGroup}>
            <label htmlFor="job-url-input" className={styles.inputLabel}>Job URL (optional)</label>
            <div className={styles.inputBox}>
              <Link2 className="icon" />
              <input
                id="job-url-input"
                value={jobUrl}
                onChange={(e) => setJobUrl(e.target.value)}
                placeholder="https://example.com/job-posting"
                className={styles.inputField}
              />
            </div>

            <label className={styles.inputLabel}>Job description text</label>
            <textarea
              value={jobText}
              onChange={(e) => setJobText(e.target.value)}
              placeholder="Paste the job post text here…"
              className={styles.textArea}
            />

            <div className={styles.buttonGroup}>
              <div className="helper-text">
                We don’t store raw text by default unless your backend enables it.
              </div>
              <button
                onClick={onAnalyze}
                disabled={!canAnalyze || loading}
                className={clsx(
                  styles.button,
                  canAnalyze && !loading ? styles.activeButton : styles.disabledButton
                )}
              >
                {loading ? <Loader2 className="loader-icon" /> : <Search className="icon" />}
                Analyze
              </button>
            </div>
          </div>
        </Card>

        <div className={styles.hintGroup}>
          <div className={styles.hint}>
            <div className={styles.hintIcon}><ShieldAlert className="icon" /></div>
            <div>
              <div className={styles.hintTitle}>Common scam signals</div>
              <div className={styles.hintText}>
                Upfront payments, “urgent hiring”, off-platform communication, unrealistic salary, vague company info.
              </div>
            </div>
          </div>
          <div className={styles.hint}>
            <div className={styles.hintIcon}><AlertTriangle className="icon" /></div>
            <div>
              <div className={styles.hintTitle}>Best practice</div>
              <div className={styles.hintText}>
                Verify domain emails, official company website, and cross-check the job on LinkedIn/company careers page.
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className={styles.rightSection}>
        <Card>
          <CardHeader title="Results" subtitle="Model output, rationale, and risk breakdown." />
          {!result && !error && !loading && <EmptyState />}

          {loading && (
            <div className={styles.loadingState}>
              <div className={styles.loadingMessage}>
                <Loader2 className="loader-icon" />
                Running NLP checks…
              </div>
              <div className={styles.subtext}>Extracting linguistic patterns, suspicious entities, and metadata signals.</div>
            </div>
          )}

          {error && (
            <div className={styles.errorState}>
              <div className={styles.errorTitle}>Couldn’t analyze</div>
              <div className={styles.errorMessage}>{error}</div>
            </div>
          )}

          {result && (
            <div className={styles.resultGrid}>
              <VerdictBanner verdict={result.verdict} summary={result.summary} confidence={result.confidence} />
              {/* Add other result components here */}
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
